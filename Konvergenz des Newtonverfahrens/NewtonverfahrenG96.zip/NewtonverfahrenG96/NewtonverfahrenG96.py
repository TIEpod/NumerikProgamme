import pa4

def main():
    '''Es müssen leider die Fenster geschlossen werden damit das nächste kommt.
    Das einiege Sachen englisch und andere deutsch benannt sind hat keinen Hintergrund.
    Die Laufzeit kann sehr lange dauern. Insbesondere Aufgabe 7'''
    pa4.exercise2()
    pa4.exercise3()
    pa4.aufgabe4()
    pa4.aufgabe5()
    pa4.aufgabe6()
    pa4.exercise7()

main()